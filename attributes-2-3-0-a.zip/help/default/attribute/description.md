The text that will be written in attribute modifiers.
Example: Max Health