If you have enabled "${l10n.t("elementgui.item.container_item")}", you can enable this option to damage the item instead
of simply keeping it in the crafting grid.