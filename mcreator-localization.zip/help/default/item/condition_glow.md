If condition is specified, the item will only glow in case this condition is passed.
This will be ignored if glow effect is disabled.