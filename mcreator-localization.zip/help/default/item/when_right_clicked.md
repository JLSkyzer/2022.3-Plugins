The procedure is executed when a player right-clicks with this item in his hand.

If you want this procedure to be only called when entity right clicks in the air with this item,
"${l10n.t("elementgui.common.event_right_clicked_block")}" procedure should always return SUCCESS/CONSUME.