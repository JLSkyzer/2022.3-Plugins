This is maximal number of items of this type that can fit in a stack. 

Vanilla example: Ender Pearls have a stack size of 16.