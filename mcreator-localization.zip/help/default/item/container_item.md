This parameter controls if the item stays in the crafting grid when crafted.
This means the item will be part of the recipe, but not consumed by it.