This parameter adds a tooltip to the block when you hold your icon over the block in your inventory.

Tips:

* Use commas "," to separate entries to a new line.
* Use the backslash with a comma after "\," to insert comma in the text instead of separating entries.