How common rare enchantments can be enchanted on this item/tool. 
The higher the enchantability, the better enchantments you will get when enchanting the item/tool.

Vanilla values:

* Wooden tools: 15
* Stone tools: 5
* Iron tools: 14
* Gold tools: 22
* Diamond tools: 10
* Netherite tools: 15
* Books: 1