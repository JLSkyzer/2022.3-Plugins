If this option is enabled, fluid sources can create more sources, similar to water. This makes it possible to have an 
infinite source.