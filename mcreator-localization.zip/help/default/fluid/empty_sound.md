This parameter controls which sound will be played when the bucket is emptied. If no sound is selected, the default bucket
sound will be played.