This parameter determines how much the fluid pushes entities when it's flowing. With negative values it will pull entities
instead of pushing them away.