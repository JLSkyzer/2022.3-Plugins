This parameter determines how rare the lakes of this fluid should be. Higher values means the lake will be rarer.

Water lakes use a value of 4.