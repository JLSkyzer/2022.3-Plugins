This parameter determines how much the level of this fluid decreases for every block it spreads to. With higher values, 
the fluid will cover a smaller area.

This value is 1 for water and lava in the Nether, 2 for lava in the Overworld.