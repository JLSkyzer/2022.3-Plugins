This parameter determines how many ticks it takes for the fluid to spread to another block. The higher this value is, the 
slower the fluid will move.

The default values are 5 for water, 30 for lava in the Overworld and 10 for lava in the Nether.