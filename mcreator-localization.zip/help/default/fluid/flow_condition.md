This condition determines if the fluid can spread from a certain position.

Keep in mind that this is also affected by other properties (nearby slopes, solid blocks etc.).