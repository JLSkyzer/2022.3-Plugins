This is the temperature of your fluid, measured in Kelvin. The higher the value, the hotter your fluid will be. 

The default value is 300K, which is around room temperature.