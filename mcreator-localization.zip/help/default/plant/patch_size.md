This parameter determines how many plants at most can generate in a single patch. Higher values mean more plants in a single
patch.