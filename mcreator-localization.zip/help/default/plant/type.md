Plant types determine where a plant can be placed by players and during world generation. 
Do keep in mind that static plants can always stay on (Coarse) Dirt, Podzol, Grass and Farmland, 
while growable plants can always stay on themselves.

You can find the full plant type list [here](https://mcreator.net/wiki/plant-types-list).