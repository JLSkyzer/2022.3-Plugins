This parameter determines the potion effect of suspicious stews crafted with this plant.

NOTE: You have to add the plant to the `minecraft:small_flowers` item tag to be able to craft suspicious stews.