Check this option to generate this plant at any height, instead of on the world surface.

This option should be enabled for plants that generate in the Nether.