Check this option if you want to customize the bounding box of this plant. 
If this isn't enabled, the bounding box will be based on the plant type. 