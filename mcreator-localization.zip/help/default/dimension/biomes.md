List of biomes to generate in this dimension. Biomes define all the features for dimension
regions such as plant types, trees, structures and mob spawning properties.

Dimension will evently distribute biomes according to the biome properties.