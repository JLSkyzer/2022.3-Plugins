This parameter will disable the water inside the dimension. When water is placed in such dimension, it
will instantly disappear so placing the water is not possible.