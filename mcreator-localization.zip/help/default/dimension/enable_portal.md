Check this parameter to enable Nether-like portal for this dimension.

You can leave this disabled and use procedures to define custom way
of entering this dimension.