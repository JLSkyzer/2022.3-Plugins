This is the game rule type. You must select the best type depending on your plan(s)
* Number means the game rule can only be modified to be a number (integer)
* Logic means the game rule can only be a boolean (true or false)