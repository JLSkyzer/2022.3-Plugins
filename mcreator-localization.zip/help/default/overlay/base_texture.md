A base texture for your overlay. Other components will be drawn over this texture.

This parameter can be used to make "pumpkin" like overlays.

Recommended overlay size is 1920 x 1080 to make is scale properly.