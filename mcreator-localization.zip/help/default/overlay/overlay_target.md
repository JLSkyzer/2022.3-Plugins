Overlay target specifies on which screen this overlay should be drawn over.

Use Ingame for overlays such as hunger bars and pumpkin-like overlays.

Use other targets to overlay other specific screens.