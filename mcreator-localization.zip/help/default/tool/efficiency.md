This parameter defines how fast the tool can mine.

Example: Stone tools have lower efficiency than diamond tools.

Vanilla values: 
* Wooden tools have 2.
* Stone tools have 4.
* Iron tools have 6.
* Diamond tools have 8.
* Netherite tools have 9.
* Gold tools have 12.