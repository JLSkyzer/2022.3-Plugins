This list defines what blocks the tool can be used on. 

This parameter is only used by the special tool type.