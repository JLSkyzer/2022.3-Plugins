If this option is checked, the item won't be dropped by dispensers with default action, but will call the
"${l10n.t("elementgui.item_extension.dispense_success_condition")}" and "${l10n.t("elementgui.item_extension.dispense_result_itemstack")}"
procedures instead.
