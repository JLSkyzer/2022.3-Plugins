This procedure determines what happens to the item after attempting at being dispensed. 
If nothing is selected or the selected procedure does not return itemstack, the current itemstack
used for dispensing will be shrank in size by 1 in case of dispense success.

You can use this procedure to consume the item, damage it, or replace it with another item.