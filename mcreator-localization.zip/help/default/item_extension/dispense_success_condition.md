This condition determines if dispense is completes. If the condition fails, the dispenser will play the fail effect.

The value of this procedure is passed to "${l10n.t("elementgui.item_extension.dispense_result_itemstack")}"
as the "success" dependency.