This number is the percentage of chance of the item to add a layer to the composter block.
Keep the value of 0 to disable it.

Vanilla values can be found [here](https://minecraft.fandom.com/wiki/Composter#Composting).