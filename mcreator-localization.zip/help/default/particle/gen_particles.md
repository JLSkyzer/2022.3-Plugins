Tick this box to enable pre-defined particle generator.

If this generator is not enough for your needs, you can use
procedures to define more complex particle patterns and conditions.