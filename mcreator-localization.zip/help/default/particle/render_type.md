This parameter defines how this particle should be rendered:

* **Opaque:** Transparent without mipmapping (similar to death particles)
* **Translucent:** Partially transparent and the most resource heavy option (similar to potion effect particles)
* **Lit:** Glowing particle that emits light during its lifetime (similar to explosion particles)
