This parameter controls if the particle is shown in all cases, 
even if the particle display is set to minimal in the video settings.