The particle will expire before its maximal age if it passes the selected condition.

If no condition is defined, particle can only expire when it reaches the maximal age in ticks.