The particle will expire as soon as its age is equal to this number of ticks.

This can happen sooner or later if maximal age diff is greater than 0.
