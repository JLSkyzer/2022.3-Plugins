The name of the advancement.
If it has not parent (root advancement) then it will be the name of the path.