Add your generation condition(s) to generate or not the structure.

Existing conditions like biome and block limitations will be checked too.

The structure will only generate if the condition procedure returns true.

Keep in mind some procedure blocks might not work properly in this trigger during early world generation.