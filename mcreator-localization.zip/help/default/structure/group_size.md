This parameter controls how many structures the game will generate around the first 
structure generated. Use this option to make forests for example.