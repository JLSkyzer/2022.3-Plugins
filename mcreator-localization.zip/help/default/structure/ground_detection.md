This parameter controls how the structure ground will be detected.

Example: If we make a structure for a water-based biome, the **first motion blocking block** 
will generate the structure below the water as the water is not considered motion blocking block
as the entities can go through it.

The **first block** detection type will generate the structure above the water.