This parameter controls how rare or common the structure is per 1,000,000 chunks.

Setting this value too high might cause slow world generation or even world gen crashes.