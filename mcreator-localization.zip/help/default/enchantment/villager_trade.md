Check this option if you want your enchantment to be sold as a villager trade.

NOTE: Only available in Minecraft 1.16.x and higher