Check this option if you want your enchantment to be able to generate in loot tables.

NOTE: Only available in Minecraft 1.16.x and higher