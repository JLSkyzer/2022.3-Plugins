Determine the compatibility with other specific enchantments.

Leave this empty to allow combining with any enchantment.

**Include** will make selected enchantments compatible.
**Exclude** will make selected enchantments incompatible.