Enchantments with this property are bad (their name are red). 

CURSE OF VANISHING and CURSE OF BINDING have this property.

Curse enchantments cannot be removed from the items.