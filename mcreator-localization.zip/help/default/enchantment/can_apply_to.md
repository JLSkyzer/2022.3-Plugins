Specify the items that can receive the enchantment (or not if in exlcude mode) in the enchanting table here.

You can also add items that aren't in the enchantment type you have defined.

In most cases you want to keep this empty (vanilla compatibility detection logic is used).

**Include** will allow selected items to receive this enchantment.
**Exclude** will not allow selected items to receive this enchantment
