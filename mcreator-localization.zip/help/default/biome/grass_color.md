This parameter controls the color of the grass in this biome.

This parameter changes the color of other plants (foliage) too.