This value defines the time, in ticks, before the sound is played (loop).

NOTE: Only available in Minecraft 1.16.x and higher