Default features are pre-configured features (Minecraft features) you can use in your biome.
