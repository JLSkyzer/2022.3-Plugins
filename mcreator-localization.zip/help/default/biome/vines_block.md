This paremeter controls the block used to replace vines.

Select air block to don't have vines.