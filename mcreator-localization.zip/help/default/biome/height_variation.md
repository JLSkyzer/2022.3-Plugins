This parameter controls the height variation of this biome.

Lower values will make this biome more even and flat, while big values will make this biome
very dynamic in terrain.

This parameter also controls placement of the biomes.
Biomes with similar height variation will generate closer together.

Biomes with the same height variation will compete for the same spot in the world when generating.