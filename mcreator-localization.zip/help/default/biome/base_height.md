This parameter controls the height at which the biome is. 
Mountains have this parameter set to a big value for example.

This parameter also controls placement of the biomes.
Biomes with similar base height will generate closer together.

Biomes with the same base height will compete for the same spot in the world when generating.