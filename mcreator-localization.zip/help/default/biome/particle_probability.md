The probability to spawn particles.

NOTE: This value is divided by 100 in the code.