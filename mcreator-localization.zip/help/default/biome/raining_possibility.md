This parameter controls the possibility of raining inside the biome.

This parameter also controls placement of the biomes.
Biomes with similar raining possibility will generate closer together.

Biomes with the same raining possibility will compete for the same spot in the world when generating.