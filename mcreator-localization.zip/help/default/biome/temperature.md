This parameter controls the temperature of the biome.

0.0 is like the Snowy Tundra, and 2.0 is like the Desert.

* Values less than 0.15 will make custom biome snow when downfall is happening
* Values between 0.15 and 1.5 make the biome rain
* Values larger than 1.5 will make the biome dry (disable rain, deserts for example)

This parameter also controls placement of the biomes.
Biomes with similar temperature will generate closer together.

Biomes with the same temperature will compete for the same spot in the world when generating.