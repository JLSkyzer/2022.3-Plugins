This condition determines if the effect should activate its tick procedure, based on the level and the duration left.

Use this condition to create effects that behave like regeneration or poison. A procedure template for this is also
available.