Select the color of the bottles and the arrow. 

You don't need this option if you don't want the items.