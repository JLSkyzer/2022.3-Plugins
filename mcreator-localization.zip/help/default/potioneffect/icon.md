This parameter controls the icon displayed inside the player's inventory when the potion is active.

IMPORTANT: If the texture name differs from the element's registry name, a copy of the texture will be made.