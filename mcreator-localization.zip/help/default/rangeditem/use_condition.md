This procedure will be called before the ranged item fires to check if the return value of the selected procedure is
true.

Keep "${l10n.t("condition.common.true")}" to disable any additional conditions. Ammo checks still apply in this case.