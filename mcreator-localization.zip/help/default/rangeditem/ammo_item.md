This parameter is controls the ammo used by the ranged item. 

Example: the arrow for the bow.