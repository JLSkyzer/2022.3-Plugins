Check this parameter if you want it to light a fire when the ranged item hits a block.

NOTE: this does not catch mobs on fire