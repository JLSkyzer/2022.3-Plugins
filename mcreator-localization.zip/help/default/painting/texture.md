Select a texture that should be used as a foreground of this painting.

IMPORTANT: If the texture name differs from the element's registry name, a copy of the texture will be made.