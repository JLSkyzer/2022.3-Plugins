This procedure will be executed when the selected key is released (after the player has pressed the key).

You can use pressedms dependency to determine for how long the key was pressed in your custom procedures.