Key binding category is category shown in controls section of Minecraft settings.

All keybindings belonging to the same category should have the same category key.

To actually set category name, go to **${l10n.t("tab.workspace")} -> ${l10n.t("workspace.category.localization")} ->
${l10n.t("workspace.localization.add_entry")}** and use `key.category.${data.keyBindingCategoryKey}` for the entry name
and then set the value to desired category name.