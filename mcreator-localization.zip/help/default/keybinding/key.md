This parameter defines the key used to execute the key binding procedure. 

Players can always change it inside the Controls.