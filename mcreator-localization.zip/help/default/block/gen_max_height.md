This parameter controls the maximum Y height that this block can generate in.

NOTE: Minecraft 1.17.x and higher supports from -2032 to 2016, but it is not recommended to use lower and higher values than 0 to 256.
With Minecraft 1.16.5 and lower, Minecraft only supports values between 0 and 256.

Vanilla maximum Y levels heights:
* Coal Ore - 125
* Iron Ore - 40
* Gold Ore - 32
* Redstone Ore - 16
* Diamond Ore - 16
* Emerald Ore - 32
* Lapis Lazuli - 31