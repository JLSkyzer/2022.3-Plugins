This parameter controls how much light the block emits. It is a value between 0 and 15. 
If set to 0, the block won't emit light. If set to 15, the block will emit as much light as glowstone.