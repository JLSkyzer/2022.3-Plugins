If block base is used, some parameters might be disabled or might not work due to the base block
requiring them on default values from the base block.

Only use this parameter if there is a good reason for it, most blocks should have this set
to Default basic block.