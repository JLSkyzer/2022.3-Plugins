This parameter defines if the player will be able to mine it. 

Vanilla examples: Bedrock and command block