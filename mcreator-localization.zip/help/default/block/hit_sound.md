This is the sound played when the player mines the block.

NOTE: This sound is played in loop while breaking until the block is broken.