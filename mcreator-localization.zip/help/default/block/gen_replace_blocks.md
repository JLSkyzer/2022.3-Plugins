List of blocks this block can replace when generating.

If you leave this list empty, the block will not naturally generate as it will not be able
to place itself on the world.