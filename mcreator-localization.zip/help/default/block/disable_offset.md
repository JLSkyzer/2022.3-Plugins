If the block has a random model offset, its bounding box will also be moved, unless this option is selected.
If the bounding box is submerging into neighboring blocks because of the offset, check this box to prevent that.

For example, this option would be false for bamboo, and true for tall grass.