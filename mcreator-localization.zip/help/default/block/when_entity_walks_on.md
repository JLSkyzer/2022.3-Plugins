Triggers a procedure when an entity walks on top of this block.

It won't be called if the entity is sneaking.