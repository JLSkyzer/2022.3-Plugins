This condition determines whether this block can be placed in a specific location. If the position is
no longer valid, the block will be broken once it receives a block update.

NOTE: This condition isn't checked during world generation.
