This is the color your block appears as on maps. 

If set to Default, the color is based on the material of the block.