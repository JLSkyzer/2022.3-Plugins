This optional property will change the texture of the particles when the block is broken,
 an entity lands on the block and so on.