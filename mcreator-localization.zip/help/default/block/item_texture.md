This optional property will change the texture of the block in the inventory.

Commonly used with doors or custom models.