If your block rotates horizontally, check this box to allow it facing floor, walls or ceiling at any direction.
This option is used by lever, grindstone, etc.