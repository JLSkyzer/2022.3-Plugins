This property determines how much the light level decreases when going through this block. For example, a value of 15
will block all the light, a value of 0 will make the block transparent for light.
