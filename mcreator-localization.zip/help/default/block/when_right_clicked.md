When a player right-clicks on the block, the procedure will be executed.

The procedure should return an action result of type SUCCESS/CONSUME if it performs an action, and PASS otherwise.
If a GUI is opened on right-click, or if the procedure doesn't return any value, then the action result type
will be SUCCESS.