This is how many items in the slots in this block's inventory can stack too.

Keep in mind that there is another slot stack size limit set for the specific items, so this is an upper limit
of the slots that can be further limited by items.