Check this parameter if you want the items to drop when the block is broken. 

Chests use this parameter, for example.