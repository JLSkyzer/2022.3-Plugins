This parameter controls how often the block will tick. If tick randomly is selected, this parameter
has no effect.

Keep in mind that usually, blocks naturally generated will not tick by default, unless tick randomly
is used.

Default tick rate of 0 means the block will not tick automatically.

If this parameter is set to a number greater than 0, the block will tick automatically. There are 20 world ticks in a second.