This parameter controls how many slots your block will use for its internal inventory.

If the block is bound to GUI, set this value to `the biggest slot ID in the GUI + 1`