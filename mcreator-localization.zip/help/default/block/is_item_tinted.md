If this option is checked, a fixed tint will be applied to the block while it's in the inventory, 
matching the tint type.

The tint is applied also when an item texture is specified.