If this parameter is checked, redstone dust will always connect to 
this block (similar to the Redstone Blocks).

NOTE: The block can still emit redstone power even if this parameter isn't checked.