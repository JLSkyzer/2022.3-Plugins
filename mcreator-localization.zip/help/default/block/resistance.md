This parameter controls how the block reacts to explosions. 
A higher value makes the block more resistant to explosions.