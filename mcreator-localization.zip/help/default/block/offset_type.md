This parameter controls if block placement should be randomly offset and by which axis.

Most plants use one of the offset types.