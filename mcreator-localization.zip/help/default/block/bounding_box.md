The block dimensions and bounding box sets the hitbox for the block if its a custom model. 
It also can resize a regular block size from something that is cube to other dimensions if no custom model is used.

This will only set the dimensions, not the shape, though.

To understand how bounding box parameters work, click [here](https://mcreator.net/wiki/block-dimensions-and-bonding-box).