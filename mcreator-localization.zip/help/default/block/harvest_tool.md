This parameter controls what tool you want to mine the block.

Ores use pickaxe here, logs axe, dirt shovel.

If set to "Not specified", players will be able to break this block with hand.
