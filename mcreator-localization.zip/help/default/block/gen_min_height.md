This parameter controls the minimum Y height that this block can generate in.

NOTE: Minecraft 1.17.x and higher supports from -2032 to 2016, but it is not recommended to use lower and higher values than 0 to 256.
With Minecraft 1.16.5 and lower, Minecraft only supports values between 0 and 256.

Vanilla minimum Y levels heights:
* Coal Ore - 1
* Iron Ore - 5
* Gold Ore - 1
* Redstone Ore - 1
* Diamond Ore - 1
* Emerald Ore - 4
* Lapis Lazuli - 1