Triggers a procedure when the block is ticked.

Naturally spawned blocks will only tick if random ticking is used for performance reasons.
