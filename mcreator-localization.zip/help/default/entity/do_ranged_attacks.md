If checked, your entity will attack with a ranged item (similar to the Skeleton). 

You can select your own ranged item from the list or use default (arrow).