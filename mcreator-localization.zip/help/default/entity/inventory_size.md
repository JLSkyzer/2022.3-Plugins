This parameter controls how many slots your entity will use for its internal inventory.

Set this value to `the biggest slot ID in the GUI + 1`.