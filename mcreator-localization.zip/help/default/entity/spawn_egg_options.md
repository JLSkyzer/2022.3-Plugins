If this parameter is checked, the first color will be the background of the egg. 
The second color will be the circles on the egg. 

You can choose the creative tab for the spawn egg too.