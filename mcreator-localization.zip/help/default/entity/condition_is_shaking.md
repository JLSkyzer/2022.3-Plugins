While the returned value is true, the entity will be shaking.
Zombie villagers use this feature during their curing.