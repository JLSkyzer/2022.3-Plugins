Texture of your entity. Make sure the texture is compatible with the model you selected.

Biped models, for example, only support 64x64 (64x32 avant Minecraft 1.18) biped type textures.