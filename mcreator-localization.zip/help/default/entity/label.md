This allows the mob to set a name that will be shown above their head similar to how the player
names or nametags are shown.