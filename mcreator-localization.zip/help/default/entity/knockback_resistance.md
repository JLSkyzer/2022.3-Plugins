The knockback resistance defines the resistance to the attack knockback of the entity.
In general, most of vanilla entities don't use it, but as a reference, the ravager has 0.5.
