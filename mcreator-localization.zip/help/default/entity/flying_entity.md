Checking this parameter makes this entity a flying entity.

This means it has flying path navigator and motion controller and has gravity and fall
damage disabled.