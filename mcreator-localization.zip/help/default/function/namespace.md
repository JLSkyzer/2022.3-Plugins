* **Mod:** Is used for your mod only. (Call such a function as `${modid}:${registryname}`)

* **Minecraft:** Is used with some Minecraft options (Call such a function as `minecraft:${registryname}`)