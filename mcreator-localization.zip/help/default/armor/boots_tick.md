When an entity has the boots equipped, the procedure will be executed each tick.

Passed entity is the entity wearing the armor, passed itemstack is the itemstack of the armor.