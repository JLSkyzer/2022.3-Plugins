Length of the music disc in ticks. 20 ticks is one second.

This parameter is used to signal Allays to stop dancing when the number of ticks 
specified in this field passes since the start of playback.
