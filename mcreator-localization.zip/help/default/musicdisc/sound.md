Select the music you want the disc plays inside the jukebox.

In order to support all jukebox features such as sound getting more silent with the distance,
make sure your sound is in MONO format.

If you intend to redistribute the mod, make sure you have the permissions to redistribute the music
you use!