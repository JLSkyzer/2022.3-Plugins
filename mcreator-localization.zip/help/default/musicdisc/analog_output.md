Analog redstone value output from the comparator when this music disc is present in the jukebox next to it.
