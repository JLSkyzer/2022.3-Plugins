Check this option to enable the storage of energy.

Blocks need to have tile entity enabled for the energy system to work properly.