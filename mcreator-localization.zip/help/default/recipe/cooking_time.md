This parameter is used by cooking type recipes to determine how long one item will cook.

Unit are ticks, so for one second of cooking time, one needs to set cooking time to 20 ticks.