This parameter controls if the crafting recipe needs to have a specified shape.

If checked, any item configuration with said items will be accepted as a recipe.