* Use "Mod" namespace to create a new recipe for your mod/data pack.
* Use "minecraft" to override vanilla recipes.