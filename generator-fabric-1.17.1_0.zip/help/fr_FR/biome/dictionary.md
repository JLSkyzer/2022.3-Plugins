**Forge**: Décrivez votre biome à l'aide de tags ici. Ces tags peuvent être utilisées par d'autres mods pour la compatibilité du biome et
les paramètres tels que les propriétés d'apparition.

**Fabric**: Comme le dictionnaire de biome est une fonctionnalité de Forge, ce paramètre est utilisé pour générer le biome dans le Nether et dans l'End.
Afin de générer votre biome dans l'Overworld, cocher simplement la case appropriée. Vous pouvez générer votre biome où vous le souhaitez, mais vous devriez suivre 1 biome = dimension.
- NETHER: Génère le biome dans le Nether.
- VOID: Génère the biome dans l'End comme une petite île. (Poids Vanilla : 1)
- RARE: Génère the biome dans l'End comme une haute terre. (Poids Vanilla : 1)