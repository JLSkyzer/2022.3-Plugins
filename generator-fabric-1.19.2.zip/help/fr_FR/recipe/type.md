Ce paramètre contrôle dans quel système d'artisanat votre recette sera disponible.

* "Crafting" se passe dans l'établi.
* "Smelting" se passe dans le four.
* "Blasting" se passe dans un haut fourneau.
* "Smoking" se passe dans le fumoir.
* "Stone cutting" se passe dans le tailleur de pierre.
* "Campfire cooking" est un clic droit sur un feu de camp.
* "Smithing" se passe dans une table de forgeron.
* "Brewing" se passe dans un alambic.

**Fabric** :
Pour les potions, les tags ne peuvent pas être utilisés.
De plus, uniquement des potions peuvent être utilisées pour l'entrée et le résultat.